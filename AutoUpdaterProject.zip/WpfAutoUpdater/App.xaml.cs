
using System.Windows;

namespace WpfAutoUpdater
{
    public partial class App : Application { }
}
