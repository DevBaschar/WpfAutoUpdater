
namespace WpfAutoUpdater.Models
{
    public record UpdateInfo(string Version, string? DownloadUrl);
}
