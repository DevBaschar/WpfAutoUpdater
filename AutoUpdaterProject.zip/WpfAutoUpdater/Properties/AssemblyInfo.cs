
using System.Reflection;

[assembly: AssemblyInformationalVersion("1.0.0")] 
